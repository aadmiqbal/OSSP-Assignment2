pthread_mutex_t lock = PTHREAD_MUTEX_INITIALIZER;

void *downtime() {
sleep(2);
pthread_mutex_lock(&lock);
root = balanceTree(root);
pthread_mutex_unlock(&lock);
sleep(2);
pthread_mutex_lock(&lock);
root = balanceTree(root);
pthread_mutex_unlock(&lock);
sleep(2);
pthread_mutex_lock(&lock);
root = balanceTree(root);
pthread_mutex_unlock(&lock);
return NULL;}


void *ServeClient(char *client) {
	
	FILE *fp1;
    	fp1 = fopen(client, "r");
    	
    	char *filename = (char *)malloc(sizeof(char)*strlen(client));
    	char *clientname = (char *)malloc(sizeof(char)*strlen(client));
    	char *np = filename;
    	strcpy(filename,client);
    	strcpy(clientname,strtok_r(np, "_",&np));
    	
    	
    	char c[1000];
   	char *point = c;
   	
	char *str1 = (char *)malloc(sizeof(char)*35);
 	//char *str2 = (char *)malloc(sizeof(char)*35);
 	
   while(fgets(c, sizeof (c), fp1) != NULL){
   
    point = c;
    
    strcpy(str1,strtok_r(point, " ",&point));
    str1[strcspn(str1, "\n")] = '\0';
    
    if(strcmp(str1,"avgSubtree")==0){
    
    	//printf("it says avgSubtree\n");
    	pthread_mutex_lock(&lock);
    	printf("%s",clientname);
    	printf("avgSubtree = %d\n",countNodes(root));
    	pthread_mutex_unlock(&lock);
    	
    }
    else if(strcmp(str1,"countNodes")==0){
    	//printf("it says countNodes\n");
    	pthread_mutex_lock(&lock);
    	printf("%s",clientname);
    	printf("countNodes = %d\n",countNodes(root));
    	pthread_mutex_unlock(&lock);
    }else{
    
    	char *str2 = (char *)malloc(sizeof(char)*35);
    	
    	strcpy(str2,strtok_r(point, " ",&point));
    	str2[strcspn(str2, "\n")] = '\0';
    	
    	if(strcmp(str1,"addNode")==0){
    		pthread_mutex_lock(&lock);
    		printf("%s",clientname);
    		printf("insertNode %s\n",str2);
    		//printf("%s\n",str2);
    		root = addNode(root,atoi(str2));
    		pthread_mutex_unlock(&lock);
    	}else{
    		//printf("it says removeNode\n");
    		pthread_mutex_lock(&lock);
    		printf("%s",clientname);
    		printf("deleteNode %s\n",str2);
    		root = removeNode(root,atoi(str2));
    		pthread_mutex_unlock(&lock);
    	}
    	free(str2);
    }
    
}
free(str1);
free(filename);
free(clientname);
return NULL;

}