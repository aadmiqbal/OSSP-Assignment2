
void *downtime() {

}

void *ServeClient(char *client) {

}
