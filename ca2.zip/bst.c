#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <unistd.h>
#include "bst.h"

/*

Place for the BST functions from Exercise 1.

*/


float avgSubtree(Node *N)
{

	// TODO: Implement this function

}


// This functions converts an unbalanced BST to a balanced BST
Node* balanceTree(Node* root)
{

	// TODO: Implement this function

}
